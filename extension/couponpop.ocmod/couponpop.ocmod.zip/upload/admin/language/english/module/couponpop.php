<?php
// Heading
$_['heading_title']       = 'Coupon Pop';

// Text
$_['text_module']         = 'Modules';
$_['text_success']        = 'Success: You have installed Coupon Pop!';

// Entry
$_['stats_counter_code']                = 'Coupon Pop Code:';

// Error
$_['error_permission']    = 'Warning: You do not have permission to modify module Coupon Pop!';
$_['error_code']          = 'Code Required';
?>
