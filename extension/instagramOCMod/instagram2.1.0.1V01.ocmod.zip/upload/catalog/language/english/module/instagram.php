<?php
// Heading
$_['heading_title'] = 'Instagram';

// Text
$_['text_tax']      = 'Ex Tax:';