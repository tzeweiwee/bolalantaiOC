Opencart

Instagram Module
Display a instagram feed on you site from any instagram user you want.
you can as many as you want. http://meijmedia.nl/opencart2.0.1.1/index.php?route=product/category&path=20

demo:http://meijmedia.nl/opencart2.0.1.1/
http://meijmedia.nl/opencart2.0.1.1/admin
demo
demo


Install
Extension Installer:
Upload the zipfile with the extension installer

ftp:
Unzip the zipfile and upload the contents of the upload folder to your server.

If your not the admin don't forget to set the rights in system>Users>Usergroups

module/instagram 

Access Permissions
Modify Permissions

Use:
Go to Extensions>>Modules>>Instagram>>install +
settings: 
limit: max 20
Resolution: 3 standard settings as from instagram
Instagram username: the desired instagram user you want on your site
likes ad comments as you wish.

Don't forget to set the status to enabled

Add the module to you layout
System>>Design>>layouts edit

More feeds go to
Go to Extensions>>Modules>>Instagram>>edit and add some more




